from django.core.exceptions import ValidationError
from django.utils.deconstruct import deconstructible


@deconstructible
class OnlyDigitsValidator:
    def __init__(self, message: str = None):
        self.message = message

    def __call__(self, value: str):
        if not value.isdigit():
            raise ValidationError(self.message)

